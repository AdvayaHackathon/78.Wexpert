// This is a temporary script to help update all preview files
// It contains the template for updating each preview file

const previewFiles = [
  "preview3.html", "preview4.html", "preview5.html", 
  "preview6.html", "preview7.html", "preview8.html", "preview9.html"
];

const bookInfo = {
  "preview3.html": {
    title: "Introduction to Python Programming",
    author: "Udayan Das, Aubrey Lawson",
    category: "Python",
    image: "Introduction-to-python.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\Introduction to Python Programming, Udayan Das, Aubrey Lawson.pdf"
  },
  "preview4.html": {
    title: "Eloquent JavaScript",
    author: "Marijn Haverbeke",
    category: "JavaScript",
    image: "elequoent-javascript.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\Eloquent JavaScript author Marijn Haverbeke.pdf"
  },
  "preview5.html": {
    title: "JavaScript for Beginners",
    author: "Daniel Winterstein",
    category: "JavaScript",
    image: "JavaScriptforBeginners.png",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\JavaScript for beginners author Daniel Winterstein.pdf"
  },
  "preview6.html": {
    title: "Dive Into HTML5",
    author: "Mark Pilgrim",
    category: "HTML/CSS",
    image: "Dive-Into-HTML5.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\Dive Into HTML5.pdf"
  },
  "preview7.html": {
    title: "The Missing Link: An Introduction to Web Development",
    author: "Michael Mendez",
    category: "HTML/CSS",
    image: "The-missing-link.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\The Missing Link. An Introduction to Web Development and Programming, Michael Mendez.pdf"
  },
  "preview8.html": {
    title: "Introduction to Programming using Java",
    author: "David J. Eck",
    category: "Java",
    image: "intoduction-to-java.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\Introduction to Programming Using Java, David J. Eck.pdf"
  },
  "preview9.html": {
    title: "An Introduction to the C Programming Language",
    author: "Tim Bailey",
    category: "C/C++",
    image: "introduction-to-c.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\Introduction to Programming Using Java, David J. Eck.pdf"
  }
};

// Template for the updated preview files
function generatePreviewTemplate(file) {
  const info = bookInfo[file];
  
  return `<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${info.title} | CodeLibrary</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root {
      --primary-color: #4361ee;
      --secondary-color: #3a0ca3;
      --accent-color: #4cc9f0;
      --text-color: #2b2d42;
      --light-text: #8d99ae;
      --background: #f8f9fa;
      --card-bg: #ffffff;
      --shadow: 0 10px 20px rgba(0,0,0,0.05);
      --hover-shadow: 0 15px 30px rgba(0,0,0,0.1);
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: var(--background);
      color: var(--text-color);
      margin: 0;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* Navigation */
    nav {
      background-color: var(--card-bg);
      box-shadow: var(--shadow);
      padding: 15px 30px;
      position: sticky;
      top: 0;
      z-index: 100;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .logo {
      font-size: 24px;
      font-weight: bold;
      color: var(--primary-color);
      display: flex;
      align-items: center;
      gap: 10px;
      text-decoration: none;
    }
    
    .back-btn {
      display: flex;
      align-items: center;
      gap: 8px;
      color: var(--primary-color);
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s ease;
      padding: 8px 16px;
      border-radius: 50px;
      border: 1px solid var(--primary-color);
    }
    
    .back-btn:hover {
      background-color: rgba(67, 97, 238, 0.1);
    }
    
    /* Main Content */
    main {
      flex: 1;
      padding: 40px 20px;
    }
    
    .container {
      max-width: 1100px;
      margin: 0 auto;
      background: var(--card-bg);
      display: flex;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: var(--shadow);
      transition: all 0.3s ease;
    }

    .left-side {
      flex: 1;
      background: linear-gradient(135deg, #f5f7fa, #e4e8f0);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 30px;
      position: relative;
      overflow: hidden;
    }
    
    .book-category {
      position: absolute;
      top: 20px;
      left: 20px;
      background-color: var(--accent-color);
      color: white;
      font-size: 14px;
      padding: 6px 12px;
      border-radius: 50px;
      font-weight: 500;
      z-index: 1;
    }

    .left-side img {
      width: 100%;
      max-width: 320px;
      border-radius: 12px;
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
      transition: transform 0.5s ease;
    }
    
    .left-side img:hover {
      transform: scale(1.03);
    }

    .right-side {
      flex: 2;
      padding: 40px;
      display: flex;
      flex-direction: column;
    }

    .book-title {
      font-size: 32px;
      font-weight: bold;
      margin-bottom: 15px;
      color: var(--text-color);
      line-height: 1.3;
    }
    
    .book-author {
      font-size: 18px;
      color: var(--light-text);
      margin-bottom: 25px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .description {
      font-size: 16px;
      color: var(--text-color);
      margin-bottom: 30px;
      line-height: 1.6;
      text-align: justify;
    }

    .rating-section {
      background-color: rgba(67, 97, 238, 0.05);
      padding: 25px;
      border-radius: 12px;
      margin-bottom: 30px;
      border: 1px solid rgba(67, 97, 238, 0.1);
    }
    
    .rating-label {
      font-size: 18px;
      font-weight: 600;
      margin-bottom: 15px;
      color: var(--text-color);
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .rating-label i {
      color: var(--primary-color);
    }

    .stars {
      font-size: 32px;
      color: #d1d1d1;
      cursor: pointer;
      display: flex;
      flex-direction: row-reverse;
      justify-content: left;
      gap: 8px;
    }

    .stars span:hover,
    .stars span:hover~span {
      color: #FFD700;
    }

    .stars .selected {
      color: #FFD700;
    }
    
    .rating-value {
      margin-top: 15px;
      font-size: 16px;
      color: var(--text-color);
      font-weight: 500;
      height: 24px;
    }

    .button-group {
      display: flex;
      gap: 15px;
      margin-top: auto;
    }
    
    .submit-btn {
      flex: 1;
      padding: 14px 20px;
      font-size: 16px;
      background-color: var(--primary-color);
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s ease;
      font-weight: 500;
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 8px;
    }

    .submit-btn:hover {
      background-color: var(--secondary-color);
      transform: translateY(-2px);
    }
    
    .download-btn {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 8px;
      background-color: var(--accent-color);
      color: white;
      text-decoration: none;
      padding: 14px 20px;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 500;
      transition: all 0.3s ease;
    }
    
    .download-btn:hover {
      background-color: #3da5d9;
      transform: translateY(-2px);
    }

    /* Footer */
    footer {
      background-color: var(--card-bg);
      padding: 25px 20px;
      text-align: center;
      color: var(--light-text);
      margin-top: 40px;
      box-shadow: 0 -5px 10px rgba(0,0,0,0.02);
    }
    
    /* Responsive Design */
    @media (max-width: 900px) {
      .container {
        flex-direction: column;
      }
      
      .left-side {
        padding: 40px;
      }
      
      .left-side img {
        max-width: 250px;
      }
    }
    
    @media (max-width: 576px) {
      nav {
        padding: 15px;
      }
      
      .right-side, .left-side {
        padding: 25px;
      }
      
      .book-title {
        font-size: 24px;
      }
      
      .button-group {
        flex-direction: column;
      }
    }
  </style>
</head>

<body>
  <nav>
    <a href="home.html" class="logo">
      <i class="fas fa-book-open"></i>
      <span>CodeLibrary</span>
    </a>
    <a href="home.html" class="back-btn">
      <i class="fas fa-arrow-left"></i>
      Back to Books
    </a>
  </nav>

  <main>
    <div class="container">
      <div class="left-side">
        <div class="book-category">${info.category}</div>
        <img src="${info.image}" alt="${info.title} Book">
      </div>

      <div class="right-side">
        <div class="book-title">${info.title}</div>
        <div class="book-author">
          <i class="fas fa-user-edit"></i>
          ${info.author}
        </div>
        <div class="description">
          <!-- Description content will be preserved from the original file -->
        </div>

        <div class="rating-section">
          <div class="rating-label">
            <i class="fas fa-star"></i>
            Rate this book
          </div>
          <div class="stars" id="starRating">
            <span data-value="5">&#9733;</span>
            <span data-value="4">&#9733;</span>
            <span data-value="3">&#9733;</span>
            <span data-value="2">&#9733;</span>
            <span data-value="1">&#9733;</span>
          </div>
          <div class="rating-value" id="ratingValue"></div>
        </div>
        
        <div class="button-group">
          <button class="submit-btn">
            <i class="fas fa-paper-plane"></i>
            Submit Rating
          </button>
          <a href="${info.pdfPath}" class="download-btn" target="_blank">
            <i class="fas fa-download"></i>
            Download PDF
          </a>
        </div>
      </div>
    </div>
  </main>
  
  <footer>
    <p>&copy; 2025 CodeLibrary. All rights reserved.</p>
  </footer>

  <script>
    // Star rating functionality
    const stars = document.querySelectorAll('#starRating span');
    const ratingValue = document.getElementById('ratingValue');
    let selectedRating = 0;

    stars.forEach(star => {
      star.addEventListener('click', () => {
        selectedRating = star.getAttribute('data-value');
        ratingValue.innerText = \`You rated this book: \${selectedRating} star\${selectedRating > 1 ? 's' : ''}\`;
        updateStars(selectedRating);
      });
    });

    function updateStars(rating) {
      stars.forEach(star => {
        if (star.getAttribute('data-value') <= rating) {
          star.classList.add('selected');
        } else {
          star.classList.remove('selected');
        }
      });
    }
    
    // Submit rating
    document.querySelector('.submit-btn').addEventListener('click', function() {
      if (selectedRating === 0) {
        alert('Please select a rating first!');
        return;
      }
      
      // Here you would normally send the rating to a server
      // For now, we'll just show a success message
      alert(\`Thank you for rating this book \${selectedRating} star\${selectedRating > 1 ? 's' : ''}!\`);
    });
  </script>

</body>

</html>`;
}
