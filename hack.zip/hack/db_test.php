<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Database Connection Test</h2>";

// Database configuration
$servername = "localhost";
$username = "root"; // update if needed
$password = "";     // update if needed
$dbname = "book_ratings"; // name of your DB

// Test connection without database first
echo "<h3>Testing MySQL Connection:</h3>";
try {
    $conn = new mysqli($servername, $username, $password);
    if ($conn->connect_error) {
        die("Connection to MySQL failed: " . $conn->connect_error);
    }
    echo "✅ Connected to MySQL server successfully!<br>";
    $conn->close();
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

// Now try to create the database if it doesn't exist
echo "<h3>Creating Database:</h3>";
try {
    $conn = new mysqli($servername, $username, $password);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $sql = "CREATE DATABASE IF NOT EXISTS $dbname";
    if ($conn->query($sql) === TRUE) {
        echo "✅ Database '$dbname' created or already exists<br>";
    } else {
        echo "❌ Error creating database: " . $conn->error . "<br>";
    }
    $conn->close();
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

// Test connection to the specific database
echo "<h3>Testing Database Connection:</h3>";
try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection to database failed: " . $conn->connect_error);
    }
    echo "✅ Connected to database '$dbname' successfully!<br>";
    $conn->close();
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

echo "<p>If all tests passed, your database connection is working correctly.</p>";
echo "<p><a href='setup_database.php' class='button'>Next: Set Up Database Tables</a></p>";

echo "<style>
body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
h2 { color: #4361ee; }
h3 { color: #3a0ca3; margin-top: 20px; }
.button { 
    display: inline-block; 
    background-color: #4361ee; 
    color: white; 
    padding: 10px 15px; 
    text-decoration: none; 
    border-radius: 4px; 
    margin-top: 20px;
}
</style>";
?>
