// This is a temporary file to help with updating all preview pages
// Book information for each preview page
const bookInfo = {
  "preview1.html": {
    title: "Python For Everybody",
    author: "Charles R. Severance",
    category: "Python",
    image: "Python-for-Everybody.jpeg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\Python for Everybody author Charles R. Severance.pdf"
  },
  "preview2.html": {
    title: "Think Python",
    author: "Allen B. Downey",
    category: "Python",
    image: "Think-python.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\thinkpython.pdf"
  },
  "preview3.html": {
    title: "Introduction to Python Programming",
    author: "Udayan Das, Aubrey Lawson",
    category: "Python",
    image: "Introduction-to-python.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\Introduction to Python Programming, Udayan Das, Aubrey Lawson.pdf"
  },
  "preview4.html": {
    title: "Eloquent JavaScript",
    author: "Marijn Haverbeke",
    category: "JavaScript",
    image: "elequoent-javascript.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\Eloquent JavaScript author Marijn Haverbeke.pdf"
  },
  "preview5.html": {
    title: "JavaScript for Beginners",
    author: "Daniel Winterstein",
    category: "JavaScript",
    image: "JavaScriptforBeginners.png",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\JavaScript for beginners author Daniel Winterstein.pdf"
  },
  "preview6.html": {
    title: "Dive Into HTML5",
    author: "Mark Pilgrim",
    category: "HTML/CSS",
    image: "Dive-Into-HTML5.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\Dive Into HTML5.pdf"
  },
  "preview7.html": {
    title: "The Missing Link: An Introduction to Web Development",
    author: "Michael Mendez",
    category: "HTML/CSS",
    image: "The-missing-link.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\The Missing Link. An Introduction to Web Development and Programming, Michael Mendez.pdf"
  },
  "preview8.html": {
    title: "Introduction to Programming using Java",
    author: "David J. Eck",
    category: "Java",
    image: "intoduction-to-java.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\Introduction to Programming Using Java, David J. Eck.pdf"
  },
  "preview9.html": {
    title: "An Introduction to the C Programming Language",
    author: "Tim Bailey",
    category: "C/C++",
    image: "introduction-to-c.jpg",
    pdfPath: "C:\\Users\\advip\\Desktop\\Book\\Introduction to Programming Using Java, David J. Eck.pdf"
  }
};
