<?php
// 1. Connect to the database
$conn = new mysqli("localhost", "root", "", "coding_for_rural_kids");

// 2. Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 3. Get form data
$name     = $_POST['name'];
$email    = $_POST['email'];
$password = $_POST['password'];
$confirm  = $_POST['confirm_password'];
$address  = $_POST['address'];
$role     = $_POST['role'];

// 4. Insert data into database
$sql = "INSERT INTO users (name, email, password, confirm_password, address, role)
        VALUES ('$name', '$email', '$password', '$confirm', '$address', '$role')";

// 5. If data is saved, go to another page
if ($conn->query($sql) === TRUE) {
    header("Location: welcome.html"); // This is the page you will go to
    exit(); // Important to stop running further code
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>