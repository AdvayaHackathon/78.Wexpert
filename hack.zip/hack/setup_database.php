<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Database Setup</h2>";

// Database configuration
$servername = "localhost";
$username = "root"; // update if needed
$password = "";     // update if needed
$dbname = "book_ratings"; // name of your DB

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("<div class='error'>Connection failed: " . $conn->connect_error . "</div>");
}
echo "✅ Connected to database successfully!<br>";

// Create books table
$books_table = "CREATE TABLE IF NOT EXISTS books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    pdf_path VARCHAR(255) NOT NULL,
    preview_page VARCHAR(50) NOT NULL
)";

if ($conn->query($books_table) === TRUE) {
    echo "✅ Books table created successfully<br>";
} else {
    echo "<div class='error'>Error creating books table: " . $conn->error . "</div>";
}

// Create ratings table
$ratings_table = "CREATE TABLE IF NOT EXISTS ratings (
    rating_id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    user_ip VARCHAR(45),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(book_id)
)";

if ($conn->query($ratings_table) === TRUE) {
    echo "✅ Ratings table created successfully<br>";
} else {
    echo "<div class='error'>Error creating ratings table: " . $conn->error . "</div>";
}

// Check if books table is empty
$result = $conn->query("SELECT COUNT(*) as count FROM books");
$row = $result->fetch_assoc();
$book_count = $row['count'];

if ($book_count == 0) {
    echo "Books table is empty. Adding sample books...<br>";
    
    // Insert book data
    $book_data = "INSERT INTO books (title, author, category, image_path, pdf_path, preview_page) VALUES
    ('Python For Everybody', 'Charles R. Severance', 'Python', 'Python-for-Everybody.jpeg', 'Python for Everybody author Charles R. Severance.pdf', 'preview1.html'),
    ('Think Python', 'Allen B. Downey', 'Python', 'Think-python.jpg', 'thinkpython.pdf', 'preview2.html'),
    ('Introduction to Python Programming', 'Udayan Das, Aubrey Lawson', 'Python', 'Introduction-to-python.jpg', 'Introduction to Python Programming, Udayan Das, Aubrey Lawson.pdf', 'preview3.html'),
    ('Eloquent JavaScript', 'Marijn Haverbeke', 'JavaScript', 'elequoent-javascript.jpg', 'Eloquent JavaScript author Marijn Haverbeke.pdf', 'preview4.html'),
    ('JavaScript for Beginners', 'Daniel Winterstein', 'JavaScript', 'JavaScriptforBeginners.png', 'JavaScript for beginners author Daniel Winterstein.pdf', 'preview5.html'),
    ('Dive Into HTML5', 'Mark Pilgrim', 'HTML/CSS', 'Dive-Into-HTML5.jpg', 'Dive Into HTML5.pdf', 'preview6.html'),
    ('The Missing Link: An Introduction to Web Development', 'Michael Mendez', 'HTML/CSS', 'The-missing-link.jpg', 'The Missing Link. An Introduction to Web Development and Programming, Michael Mendez.pdf', 'preview7.html'),
    ('Introduction to Programming using Java', 'David J. Eck', 'Java', 'intoduction-to-java.jpg', 'Introduction to Programming Using Java, David J. Eck.pdf', 'preview8.html'),
    ('An Introduction to the C Programming Language', 'Tim Bailey', 'C/C++', 'introduction-to-c.jpg', 'Introduction to Programming Using Java, David J. Eck.pdf', 'preview9.html')";

    if ($conn->multi_query($book_data)) {
        echo "✅ Sample books added successfully<br>";
    } else {
        echo "<div class='error'>Error adding sample books: " . $conn->error . "</div>";
    }
} else {
    echo "✅ Books table already contains $book_count books<br>";
}

// Create view for average ratings
$conn->next_result(); // Clear any previous result sets
$view_query = "CREATE OR REPLACE VIEW book_ratings_view AS
SELECT 
    b.book_id,
    b.title,
    b.author,
    b.category,
    COUNT(r.rating_id) AS total_ratings,
    ROUND(AVG(r.rating), 1) AS average_rating
FROM 
    books b
LEFT JOIN 
    ratings r ON b.book_id = r.book_id
GROUP BY 
    b.book_id, b.title, b.author, b.category";

if ($conn->query($view_query) === TRUE) {
    echo "✅ Book ratings view created successfully<br>";
} else {
    echo "<div class='error'>Error creating view: " . $conn->error . "</div>";
}

$conn->close();

echo "<h3>Database Setup Complete!</h3>";
echo "<p>Your database has been set up successfully. You can now use the rating system.</p>";
echo "<p><a href='test_rating.php' class='button'>Next: Test Rating System</a></p>";
echo "<p><a href='admin_ratings.php' class='button secondary'>View Admin Panel</a></p>";

echo "<style>
body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
h2 { color: #4361ee; }
h3 { color: #3a0ca3; margin-top: 20px; }
.error { color: red; background-color: #ffeeee; padding: 10px; border-radius: 4px; margin: 10px 0; }
.button { 
    display: inline-block; 
    background-color: #4361ee; 
    color: white; 
    padding: 10px 15px; 
    text-decoration: none; 
    border-radius: 4px; 
    margin-right: 10px;
}
.secondary {
    background-color: #4cc9f0;
}
</style>";
?>
