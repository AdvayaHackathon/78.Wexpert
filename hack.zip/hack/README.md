# CodeLibrary - Book Rating System

This project is a digital library of coding books with a rating system that stores user ratings in a database.

## Setup Instructions

### 1. Database Setup

1. Make sure you have MySQL installed and running on your server
2. Create a new database named `book_ratings`
3. Import the database schema from `database_setup.sql`:

```bash
mysql -u root -p book_ratings < database_setup.sql
```

4. Update database credentials in `submit_rating.php` and `get_book_info.php` if needed:

```php
$servername = "localhost";
$username = "root"; // update if needed
$password = "";     // update if needed
$dbname = "book_ratings";
```

### 2. PHP Server Setup

1. Make sure you have PHP installed (version 7.0 or higher recommended)
2. Place all files in your web server directory (e.g., Apache's htdocs folder)
3. Ensure the web server has write permissions to the database

### 3. Testing the Rating System

1. Open the website in your browser
2. Navigate to any book preview page
3. Rate the book by clicking on the stars
4. Click the "Submit Rating" button
5. The rating should be saved to the database and the average rating should update

## Files Overview

- `database_setup.sql`: SQL script to create the database schema and initial data
- `submit_rating.php`: PHP script to handle rating submissions
- `get_book_info.php`: PHP script to retrieve book information and ratings
- `preview*.html`: Book preview pages with rating functionality
- `home.html`: Main page with book listings
- `style.css`: Main stylesheet

## Rating System Features

- Users can rate books on a scale of 1-5 stars
- Ratings are stored in a MySQL database
- Users can update their previous ratings
- Average ratings are displayed for each book
- User's previous ratings are remembered (based on IP address)
- Rating statistics show the average rating and total number of ratings

## Customization

To add new books to the system:

1. Add the book information to the `books` table in the database
2. Create a new preview page for the book
3. Add the book card to the home page

## Troubleshooting

If you encounter issues with the rating system:

1. Check that the database connection details are correct
2. Ensure PHP has permission to connect to MySQL
3. Check the browser console for JavaScript errors
4. Verify that the book IDs in the database match the ones in the preview pages
