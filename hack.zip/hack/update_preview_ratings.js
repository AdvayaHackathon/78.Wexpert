// This script contains the template for updating all preview pages with database rating functionality

const ratingStatsHTML = `
<div class="rating-stats" id="ratingStats">
  <div class="avg-rating">Average: <span id="avgRating">0.0</span>/5</div>
  <div class="total-ratings">(<span id="totalRatings">0</span> ratings)</div>
</div>
`;

const ratingStatsCSS = `
.rating-stats {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin-top: 15px;
  font-size: 14px;
  color: var(--light-text);
}

.avg-rating {
  font-weight: 500;
}

#avgRating {
  color: #FFD700;
  font-weight: 600;
}
`;

const ratingScript = `
// Book information and rating functionality
let bookId = 0;
let selectedRating = 0;
const stars = document.querySelectorAll('#starRating span');
const ratingValue = document.getElementById('ratingValue');
const avgRatingElement = document.getElementById('avgRating');
const totalRatingsElement = document.getElementById('totalRatings');

// Load book information and user's previous rating if any
window.addEventListener('DOMContentLoaded', function() {
  // Get the current page filename
  const currentPage = window.location.pathname.split('/').pop();
  
  // Fetch book information from the server
  fetch(\`get_book_info.php?preview_page=\${currentPage}\`)
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        // Store book ID for rating submission
        bookId = data.book.book_id;
        
        // Update average rating display
        avgRatingElement.textContent = data.book.average_rating || '0.0';
        totalRatingsElement.textContent = data.book.total_ratings || '0';
        
        // If user has already rated, show their rating
        if (data.book.user_rating > 0) {
          selectedRating = data.book.user_rating;
          ratingValue.innerText = \`You rated this book: \${selectedRating} star\${selectedRating > 1 ? 's' : ''}\`;
          updateStars(selectedRating);
        }
      } else {
        console.error('Error loading book information:', data.message);
      }
    })
    .catch(error => {
      console.error('Error fetching book information:', error);
    });
});

// Star rating functionality
stars.forEach(star => {
  star.addEventListener('click', () => {
    selectedRating = parseInt(star.getAttribute('data-value'));
    ratingValue.innerText = \`You rated this book: \${selectedRating} star\${selectedRating > 1 ? 's' : ''}\`;
    updateStars(selectedRating);
  });
});

function updateStars(rating) {
  stars.forEach(star => {
    if (parseInt(star.getAttribute('data-value')) <= rating) {
      star.classList.add('selected');
    } else {
      star.classList.remove('selected');
    }
  });
}

// Submit rating
document.querySelector('.submit-btn').addEventListener('click', function() {
  if (selectedRating === 0) {
    alert('Please select a rating first!');
    return;
  }
  
  // Create form data for submission
  const formData = new FormData();
  formData.append('book_id', bookId);
  formData.append('rating', selectedRating);
  
  // Send rating to server
  fetch('submit_rating.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Show success message
      alert(data.message);
      
      // Update average rating display
      avgRatingElement.textContent = data.average_rating || '0.0';
      totalRatingsElement.textContent = data.total_ratings || '0';
    } else {
      alert('Error: ' + data.message);
    }
  })
  .catch(error => {
    console.error('Error submitting rating:', error);
    alert('An error occurred while submitting your rating. Please try again.');
  });
});
`;
