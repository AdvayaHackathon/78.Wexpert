<?php
// Database configuration
$servername = "localhost";
$username = "root"; // update if needed
$password = "";     // update if needed
$dbname = "book_ratings"; // name of your DB

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

echo "Connected successfully to the database!<br>";

// Test query to check if tables exist
$tables_query = "SHOW TABLES";
$tables_result = $conn->query($tables_query);

if ($tables_result->num_rows > 0) {
  echo "<h3>Tables in the database:</h3>";
  echo "<ul>";
  while($row = $tables_result->fetch_row()) {
    echo "<li>" . $row[0] . "</li>";
  }
  echo "</ul>";
  
  // Check books table
  $books_query = "SELECT * FROM books LIMIT 5";
  $books_result = $conn->query($books_query);
  
  if ($books_result && $books_result->num_rows > 0) {
    echo "<h3>Sample books in the database:</h3>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Title</th><th>Author</th><th>Category</th></tr>";
    
    while($row = $books_result->fetch_assoc()) {
      echo "<tr>";
      echo "<td>" . $row["book_id"] . "</td>";
      echo "<td>" . $row["title"] . "</td>";
      echo "<td>" . $row["author"] . "</td>";
      echo "<td>" . $row["category"] . "</td>";
      echo "</tr>";
    }
    
    echo "</table>";
  } else {
    echo "No books found in the database or error querying books table.";
  }
  
} else {
  echo "No tables found in the database.";
}

$conn->close();
?>
